<?php

defined('TYPO3_MODE') or die();

// Register as a skin
$GLOBALS['TBE_STYLES']['skins']['dms-backend10'] = [
    'name' => 'dms-backend10',
    'stylesheetDirectories' => [
        'css' => 'EXT:dms/backend/Resources/Public/Css/'
    ]
];