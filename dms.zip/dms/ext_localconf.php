<?php
defined('TYPO3_MODE') || die('Access denied.');

$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(
   \TYPO3\CMS\Core\Imaging\IconRegistry::class
);
$iconRegistry->registerIcon(
   $identifier,
   \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
		['source' => 'EXT:dms/Resources/Public/Icons/Extension.svg']
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig('@import "EXT:dms/Configuration/TSconfig/BackendLayouts.tsconfig"');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig('@import "EXT:dms/Configuration/TSconfig/Page.tsconfig"');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addUserTSConfig('@import "EXT:dms/Configuration/TSconfig/User.tsconfig"');

$GLOBALS['TYPO3_CONF_VARS']['EXTENSIONS']['dms-backend10'] = [
    'backendFavicon' => 'EXT:dms/backend/Resources/Public/Images/favicon.gif',
    'backendLogo' => 'EXT:dms/backend/Resources/Public/Images/logo.png',
    'loginBackgroundImage' => 'EXT:dms/backend/Resources/Public/Images/bg.svg',
    'loginLogo' => 'EXT:dms/backend/Resources/Public/Images/logo.png',
    'loginHighlightColor' => '#c5c5c5',
    'loginFootnote' => 'Ein Service der DATA Media Service ©DMS',
];