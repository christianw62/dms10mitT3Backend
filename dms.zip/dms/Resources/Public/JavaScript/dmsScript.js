/*Formularsprechblasen abschalten start*/
var forms = document.getElementsByTagName('form');
for (var i = 0; i < forms.length; i++) {
  forms[i].addEventListener('invalid', function(e) {
    e.preventDefault();

    //eigene Sprechblase mit individualisierter Fehlermeldung.
    showOwnErrorMessage('validationErrorMessages');   
  }, true);
}

function validateForm() {
  var x = document.forms["kontakt"]["name"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
} 
/*Formularsprechblasen abschalten end*/
/*Lightbox start*/
	jQuery(document).ready(function($) {
		$('a[data-rel^=lightcase]').lightcase({
			maxHeight: 1200,
			maxwidth:1200
		});
	});
/*lightbox end*/

/*Cookiemeldung start*/
 $(document).ready(function(){
  $.cookieBar();
});
/*Cookiemeldung ende*/	

