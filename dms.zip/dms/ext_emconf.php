<?php
$EM_CONF[$_EXTKEY] = [
    'title' => 'DMS-Entwicklung Typo3.10',
    'description' => 'Dient alleine zur Entwicklung',
    'category' => 'templates',
    'author' => 'Christian Wiersgowski',
    'author_email' => 'info@data-media-service.de',
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'version' => '1.0.1',
    'constraints' => [
        'depends' => [
            'typo3' => '10.4.0-10.4.99',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
